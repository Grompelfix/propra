#pragma once
#define CMATH_N 624

class MTRandom
{
	// DATA
	private:
		unsigned int m_rseed;
		unsigned int m_rseed_sp;
		/* the array for the state vector */
		unsigned long m_mt[CMATH_N];
		int m_mti; 	// m_mti==N+1 means
					// m_mt[N] is not initialized
	// FUNCTIONS
	public:
		MTRandom(void);

		unsigned int Random(unsigned int n);
		float Random( );
		void SetRandomSeed(unsigned int n);
		unsigned int GetRandomSeed(void);
		void Randomize(void);
};
