#include "MTRandom.h"

MTRandom::MTRandom(void)
{
}

void MTRandom::SetRandomSeed(unsigned int n)
{
	m_mti = 0;
	m_mt[0] = n;
	for(int i = 1; i < CMATH_N; i++)
	{
		m_mt[i] = (0x6c078965 * (m_mt[i-1] ^ (m_mt[i-1] >> 30)) + i) & 0xffffffff;
	}
}

unsigned int MTRandom::GetRandomSeed(void)
{
	return m_mt[0];
}

unsigned int MTRandom::Random(unsigned int n)
{
	return n;
}

float MTRandom::Random(void)
{
	if(m_mti == 0)
		Randomize();

	m_rseed = m_mt[m_mti];
	m_rseed ^= (m_rseed >> 11);
	m_rseed ^= (m_rseed << 7) & 0x9d2c5680;
	m_rseed ^= (m_rseed << 15) & 0xefc60000;
	m_rseed ^= (m_rseed >> 18);

	m_mti = ++m_mti % CMATH_N;

	return m_rseed / 4294967296.;
}

void MTRandom::Randomize(void)
{
	for(int i = 0; i < CMATH_N; i++)
	{
		m_rseed = (m_mt[i] & 0x80000000) + (m_mt[(i+1) % CMATH_N] & 0x7fffffff);
		m_mt[i] = m_mt[(i+397) % CMATH_N] ^ (m_rseed >> 1);
		if(m_rseed % 2 != 0)
		{
			m_mt[i] = m_mt[i] ^ 0x9908b0df;
		}
	}
}
