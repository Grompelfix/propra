#include "MTRandom.h"
#include <iostream>

int main(void)
{
	int temp;
	MTRandom mt;
	std::cin >> temp;
	mt.SetRandomSeed(temp);
	int test[10];
	for(int i = 0; i < temp; i++)
	{
		test[(int) (mt.Random() * 10)]++;
	}
	std::cout << "Ergebnis: " << std::endl;
	for(int i = 0; i < 10; i++) {
		std::cout << test[i] << std::endl;
	}
}
